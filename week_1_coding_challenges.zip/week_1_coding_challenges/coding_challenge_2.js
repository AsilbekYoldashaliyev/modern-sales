function calculateTotalLogs(treeCount, branchCount, logsPerBranch) {
  // Calculate the total logs by multiplying treeCount, branchCount, and logsPerBranch
  // It should return : `You can get a total of totalLogs logs from treeCount trees.`
}

// Example usage:
const treeCount = 3;
const branchCount = 5; // Assuming all trees have the same number of branches
const logsPerBranch = 3; // Adjust as needed

const totalLogs = calculateTotalLogs(treeCount, branchCount, logsPerBranch);
console.log(totalLogs);
