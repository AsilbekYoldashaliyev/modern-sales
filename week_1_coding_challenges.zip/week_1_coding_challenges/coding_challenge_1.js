////////////////////////////////////
// Coding Challenge #1 (Uzbek Version)

/*
Biz yangi bir dastur yozmoqchimiz. Dasturning maqsadi ikki o'quvchi orasidagi yosh farqini aniqlash. Yoshlar o'quvchilarning tug'ilgan yillaridan hisoblanadi.

O'quvchi 1ning tug'ilgan yilini "talaba1_yil" deb nomlang va qiymatini o'zgartiring.
O'quvchi 2ning tug'ilgan yilini "talaba2_yil" deb nomlang va qiymatini o'zgartiring.
Yoshlarini aniqlash uchun "yosh_farqi" deb nomlangan o'zgaruvchini yaratish va ikki o'quvchining yosh farqini shu o'zgaruvchiga saqlang.
"yosh_farqi" o'zgaruvchisini ekranga chiqaring va "Talaba 1, Talaba 2 dan ... yil katta" deb ko'rsatish.
TEST DATA:
Talaba 1, 2000 yilida tug'ilgan.
Talaba 2, 1998 yilida tug'ilgan.

MUVAFFAQIYATLAR! 😊
*/

// Siz yuqoridagi vazifani bajarishingizni va "talaba1_yil", "talaba2_yil" va "yosh_farqi" o'zgaruvchilarini to'g'ri ekranga chiqarishingizni kutamiz.